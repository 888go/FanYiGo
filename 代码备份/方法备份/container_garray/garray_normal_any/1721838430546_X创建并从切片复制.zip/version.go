package gf

const (
	// VERSION is the current GoFrame version.
	VERSION = "v2.7.1"
)
